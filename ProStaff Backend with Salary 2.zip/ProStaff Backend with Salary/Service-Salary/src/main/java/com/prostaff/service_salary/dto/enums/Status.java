package com.prostaff.service_salary.dto.enums;

public enum Status {
	PRESENT, ABSENT, HOLIDAY, CHECKEDIN, PENDING
}
