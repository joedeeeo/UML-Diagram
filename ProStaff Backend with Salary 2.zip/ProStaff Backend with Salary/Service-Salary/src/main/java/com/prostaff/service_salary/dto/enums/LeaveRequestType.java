package com.prostaff.service_salary.dto.enums;

public enum LeaveRequestType {
	PAID, UNPAID, SICK
}
