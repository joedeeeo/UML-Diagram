package com.prostaff.service_salary.dto.enums;

public enum LeaveRequestStatus {
	ACCEPTED, REJECTED, PENDING
}
