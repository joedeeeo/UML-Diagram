package com.prostaff.service_salary.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EmployeeEmailWrapper {
	
	String employeeEmail;
	
}
