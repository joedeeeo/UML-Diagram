package com.prostaff.service_organization.inter_service_communication.enums;

public enum Gender {
	MALE, FEMALE
}
