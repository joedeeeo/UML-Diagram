package com.prostaff.service.leave.request.exception;

public class LeaveRequestNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
