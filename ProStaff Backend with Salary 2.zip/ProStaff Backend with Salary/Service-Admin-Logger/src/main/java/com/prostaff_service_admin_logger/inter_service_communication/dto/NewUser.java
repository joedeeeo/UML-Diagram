package com.prostaff_service_admin_logger.inter_service_communication.dto;

public class NewUser {
	
	String email; 
	String password; 
	String organizationName; 
	String fullName;
}
