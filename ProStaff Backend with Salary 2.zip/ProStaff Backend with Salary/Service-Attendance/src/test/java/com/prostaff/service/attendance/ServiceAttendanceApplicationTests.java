package com.prostaff.service.attendance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceAttendanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
