package com.prostaff.service.designation.inter_service_communication.dto;

import lombok.Data;

@Data
public class NewDesignation {

	String name;
	String description;
	String adminEmail;
}
