package com.prostaff.service.team.inter_service_communication.dto;

import lombok.Data;

@Data
public class TeamBasicInformation {

	 Long id;
	 String name; 
	 String description;
	 Long employeeCount;
}
